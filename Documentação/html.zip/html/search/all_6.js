var searchData=
[
  ['texto_0',['Texto',['../class_texto.html',1,'']]]
];
